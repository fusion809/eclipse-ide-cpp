#!/bin/sh
exec /opt/eclipse-ide-cpp/eclipse
